//
//  RoundButton.swift
//  TaschenrechnerFinish
//
//  Created by Til Schwarze on 01.06.21.
//

import UIKit

@IBDesignable
class RoundButton: UIButton {
    override public func layoutSubviews() {
        super.layoutSubviews()
        
        layer.cornerRadius = frame.height / 2
        clipsToBounds = true
    }
}
