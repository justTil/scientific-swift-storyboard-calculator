//
//  ViewController.swift
//  TaschenrechnerFinish
//
//  Created by Til Schwarze on 01.06.21.
//

import UIKit

// Array for the calculation
var calculationArray: [Character] = []


class ViewController: UIViewController {
    
    //  Shows result and what is displayed to the user
    @IBOutlet weak var resultLabel: UILabel!
    
    var userIsInTheMiddleOfTyping: Bool = false
    var usedEqualAlready: Bool = false
    var decimalPointUsed: Bool = false
    var bracketsOpen: Int = 0
    var result: Double = 0.0
    var choosingOperator: String = ""
    
    //-------------------------------------------------------------------------------------
    // The following functions are the standard operations you can do on a calculator
    //-------------------------------------------------------------------------------------
    // Press it, and it adds the numbers etc. to the array
    @IBAction func numberButton_Tapped(_ sender: RoundButton) {
        let key = Character(sender.currentTitle!)
        calculationArray.append(key)
        let showNumbers = String(calculationArray)
        resultLabel.text = showNumbers
    }

    // Press the euqual button, and it saves your calculation and shows it to you
    @IBAction func equalButton_Tapped(_ sender: RoundButton) {
        if bracketsOpen != 0 {
            while bracketsOpen > 0 {
                calculationArray.append(")")
                bracketsOpen -= 1
            }
        }
        print(calculationArray)
        var myString: String = ""
        myString = String(calculationArray)
        let str = NSExpression(format: "\(myString)")
        let value1 = str.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
        print(value1!)
        resultLabel.text = String(value1!)
        let midSave = String(value1!)
        calculationArray.removeAll()
        for char in midSave {
            calculationArray.append(char)
            print(calculationArray)
            let showNumbers = String(calculationArray)
            resultLabel.text = showNumbers
        }
        decimalPointUsed = true
    }
    
    // Switch between positive and negative signs in front of the number
    @IBAction func plusMinus_Tapped(_ sender: RoundButton) {
        var divideBy: Double = Double(resultLabel.text!)!
        if divideBy > 0 {
            divideBy = -divideBy
            calculationArray.removeAll()
            let midSave = String(divideBy)
            for char in midSave {
                calculationArray.append(char)
                print(calculationArray)
                let showNumbers = String(calculationArray)
                resultLabel.text = showNumbers
            }
        }
        else if divideBy < 0 {
            divideBy = -divideBy
            calculationArray.removeAll()
            let midSave = String(divideBy)
            for char in midSave {
                calculationArray.append(char)
                print(calculationArray)
                let showNumbers = String(calculationArray)
                resultLabel.text = showNumbers
            }
        }
        else if divideBy == 0 {
            divideBy = 0
            calculationArray.removeAll()
            let midSave = String(divideBy)
            for char in midSave {
                calculationArray.append(char)
                print(calculationArray)
                let showNumbers = String(calculationArray)
                resultLabel.text = showNumbers
                
            }
        }
    }
    
    // Divide by a hundred -> 8/100 = 0.08
    @IBAction func divideByAHundred_Tapped(_ sender: RoundButton) {
        var divideBy: Double = Double(resultLabel.text!)!
        divideBy /= 100
        calculationArray.removeAll()
        let midSave = String(divideBy)
        for char in midSave {
            calculationArray.append(char)
            print(calculationArray)
            let showNumbers = String(calculationArray)
            resultLabel.text = showNumbers
        }
        print(divideBy)
        var myString: String = ""
        myString = String(divideBy)
        print(myString)
        let str = NSExpression(format: "\(myString)")
        print(str)
        let value1 = str.expressionValue(with: nil, context: nil) as? Double
        print(value1!)
        resultLabel.text = String(value1!)
    }
    
    // Add a decimal to your calculation
    @IBAction func addDecimal_Tapped(_ sender: RoundButton) {
        if decimalPointUsed == false {
            var key = Character(sender.currentTitle!)
            if key == "," {
                key = "."
            }
            calculationArray.append(key)
            let showNumbers = String(calculationArray)
            resultLabel.text = showNumbers
            decimalPointUsed = true
        }

    }
    
    // This is the clear button
    @IBAction func clearButton_Tapped(_ sender: RoundButton) {
        calculationArray.removeAll()
        //print("AC Button Pressed: \(calculationArray)")
        result = 0
        choosingOperator = ""
        resultLabel.text = "0"
        usedEqualAlready = false
        decimalPointUsed = false
        print(calculationArray)
        bracketsOpen = 0
        // Make console clear/scroll down, makes it easier to debug
        print("any value", terminator: Array(repeating: "\n", count: 5).joined())
        
        
    }
    
    
    //-------------------------------------------------------------------------------------
    // The following functions are all only available in the landscape mode
    //-------------------------------------------------------------------------------------
    // This block will add Brackets to the resultLabe.text
    @IBAction func openBracket_Tapped(_ sender: RoundButton) {
        func addPressedButtonToTitle() {
            let operatorType = Character(sender.currentTitle!)
            calculationArray.append(operatorType)
            resultLabel.text = String(calculationArray)
        }
        
        if sender.currentTitle == "(" {
            addPressedButtonToTitle()
            bracketsOpen += 1
            print(bracketsOpen)
        }
        else if sender.currentTitle == ")" {
            addPressedButtonToTitle()
            bracketsOpen -= 1
            print(bracketsOpen)
        }
    }
    
    @IBAction func operationButton_Tapped(_ sender: RoundButton) {
        
        // Function to add the typed operator to the Array
        func addOperatorToTitle() {
            let operatorType = Character(sender.currentTitle!)
            calculationArray.append(operatorType)
            resultLabel.text = String(calculationArray)
        }
        if sender.currentTitle == "+" {
            addOperatorToTitle()
            decimalPointUsed = false

        }
        else if sender.currentTitle == "-" {
            addOperatorToTitle()
            decimalPointUsed = false

        }
        else if sender.currentTitle == "*" {
            addOperatorToTitle()
            decimalPointUsed = false

        }
        else if sender.currentTitle == "/" {
            addOperatorToTitle()
            decimalPointUsed = false

        }
    }
    //-------------------------------------------------------------------------------------
    @IBAction func second_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func powerOfNumber_Tapped(_ sender: RoundButton) {
        if calculationArray.isEmpty {
            
        }
        else {
            calculationArray.append("*")
            calculationArray.append("*")
            calculationArray.append("2")
            
            var myString: String = ""
            myString = String(calculationArray)
            let str = NSExpression(format: "\(myString)")
            let value1 = str.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
            resultLabel.text = String(value1!)
        }
    }
    
    @IBAction func powerOfThree_Tapped(_ sender: RoundButton) {
        if calculationArray.isEmpty {
            
        }
        else {
            calculationArray.append("*")
            calculationArray.append("*")
            calculationArray.append("3")
            
            var myString: String = ""
            myString = String(calculationArray)
            let str = NSExpression(format: "\(myString)")
            let value1 = str.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
            resultLabel.text = String(value1!)
        }
    }
    
    @IBAction func powerOfXandY(_ sender: RoundButton) {
    }
    
    @IBAction func useE_Tapped(_ sender: RoundButton) {
        func theNumbersOfE() {
            let numbersOfE: [Character] = ["*", "*",
                                           "2", ".",
                                           "7", "1", "8",
                                           "2", "8", "1",
                                           "8", "2", "8",
                                           "4", "5", "9",
                                           "0", "4", "5",
                                           "2", "3", "5",
                                           "3", "6", "0",
                                           "2", "8", "7",
                                           "4", "7", "1",
                                           "3", "5", "2"]
            
            for char in numbersOfE {
                calculationArray.append(char)
            }
            var myString: String = ""
            myString = String(calculationArray)
            let str = NSExpression(format: "\(myString)")
            let value1 = str.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
            print(value1!)
            resultLabel.text = String(value1!)
        }
        print(calculationArray)
        if calculationArray.isEmpty {
            calculationArray.append("1")
            print(calculationArray)
            theNumbersOfE()
        }
        else {
            theNumbersOfE()
        }
    }
    
    @IBAction func tenToThePowerofX(_ sender: RoundButton) {
    }
    //-------------------------------------------------------------------------------------
    @IBAction func oneDividedByInput_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func root_Tapped(_ sender: RoundButton) {
        calculationArray.append("*")
        calculationArray.append("*")
        calculationArray.append("(")
        calculationArray.append("0")
        calculationArray.append(".")
        calculationArray.append("5")
        calculationArray.append(")")
        resultLabel.text = String(calculationArray)
        
        var myString: String = ""
        myString = String(calculationArray)
        let str = NSExpression(format: "\(myString)")
        let value1 = str.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
        print(value1!)
        resultLabel.text = String(value1!)
    }
    
    @IBAction func rootOfThree_Tapped(_ sender: RoundButton) {
        calculationArray.append("*")
        calculationArray.append("*")
        calculationArray.append("(")
        calculationArray.append("1")
        calculationArray.append("/")
        calculationArray.append("3")
        calculationArray.append(")")
        resultLabel.text = String(calculationArray)
        
        var myString: String = ""
        myString = String(calculationArray)
        let str = NSExpression(format: "\(myString)")
        let value1 = str.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
        print(value1!)
        resultLabel.text = String(value1!)
    }
    
    @IBAction func individualRoot_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func ln_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func logOfTen_Tapped(_ sender: RoundButton) {
    }
    
    //-------------------------------------------------------------------------------------
    @IBAction func factorialCalculation_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func sin_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func cos_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func tan_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func eButton_Tapped(_ sender: RoundButton) {
    }
    
    @IBAction func EEButton_Tapped(_ sender: RoundButton) {
    }
    //-------------------------------------------------------------------------------------
    
    // Functions you have to add
    // Show Status bar at the top
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //  Do any additional setup after loading the view.
    }
}

